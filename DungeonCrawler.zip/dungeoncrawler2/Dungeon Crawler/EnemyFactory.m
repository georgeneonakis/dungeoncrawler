//
//  EnemyFactory.m
//  
//
//  Created by Dylan Burden on 2018-12-11.
//

#import <Foundation/Foundation.h>
#import "EnemyFactory.h"
#import "GameEngine.h"

@implementation EnemyFactory


// Factory method to create enemies and assign their AI
-(Enemy *)createEnemyWithName:(NSString *)name AtXPos:(int)x YPos:(int)y {
    Enemy *enemy;
    
    if( [name  isEqual: @"Slime"] ) {
        // Slime Ai
        AIBlock ai = ^void(GameEngine* engine, Entity* ent){
            if( ent.lifetime % 2 == 0 ) {
                [ent updateImageTo:@"Slime_Enemy_Sprite1.png"];
            }
            else {
                [ent updateImageTo:@"Slime_Enemy_Sprite0.png"];
            }
            int val = rand() % 101;
            if( val < 50 )
            {
                int moveX = 0;
                int moveY = 0;
                val = rand() % 4;
                switch ( val ) {
                    case 0:
                        moveX = 0;
                        moveY = -1;
                        break;
                    case 1:
                        moveX = 1;
                        moveY = 0;
                        break;
                    case 2:
                        moveX = 0;
                        moveY = 1;
                        break;
                    case 3:
                        moveX = -1;
                        moveY = 0;
                        break;
                    default:
                        break;
                }
                
                [engine updatePositionOfEntity:ent ByX:moveX Y:moveY];
            }
            
            ent.lifetime++;
        };
        
        enemy = [[Enemy alloc] initWithX:x Y:y
                                  Blocks:false Image:@"Slime_Enemy_Sprite0.png" Health:1];
        enemy.ai = ai;
    }
    
    // Sprout Ai
    else if( [name  isEqual: @"Sprout"] ) {
        AIBlock ai = ^void(GameEngine* engine, Entity* ent){
            if( ent.lifetime % 3 == 0 ) {
                [ent updateImageTo:@"Sprout_Enemy_Sprite1.png"];
                int projX;
                int projY;
                int dir;
                
                int posX = [ent getXPosition];
                int posY = [ent getYPosition];
            
                int playerX = [engine.player getXPosition];
                int playerY = [engine.player getYPosition];
            
                int xDif = posX - playerX;
                int yDif = posY - playerY;
            
                int deltaX = abs(xDif);
                int deltaY = abs(yDif);

                if( deltaX > deltaY ) {
                    if( xDif < 0 ) {
                        projX = posX+1;
                        projY = posY;
                        dir = 1;
                    }
                    else {
                        projX = posX-1;
                        projY = posY;
                        dir = 3;
                    }
                }
                else {
                    if( yDif < 0 ) {
                        projX = posX;
                        projY = posY+1;
                        dir = 2;
                    }
                    else {
                        projX = posX;
                        projY = posY-1;
                        dir = 0;
                    }
                }
                if ( projX < 0 || projX >= [engine.gridView getWidth] || projY < 0 || projY >= [engine.gridView getHeight] ) {
                    return;
                }
                if (((Tile*)engine.grid[projX][projY]).object == nil) {
                    Entity * proj = [self createEnemyWithName:@"Projectile" AtXPos:projX YPos:projY];
                    proj.direction = dir;
                    [engine.entitiesToAdd addObject:proj];
                }
                else {
                    if( [((Tile*)engine.grid[projX][projY]).object isKindOfClass:[Player class]] ) {
                        Player *player = (Player *)((Tile*)engine.grid[projX][projY]).object;
                        [player causeDamage:1];
                    }
                }
            }
            else {
                [ent updateImageTo:@"Sprout_Enemy_Sprite0.png"];
            }
            ent.lifetime++;
        };
        
        
        enemy = [[Enemy alloc] initWithX:x Y:y
                                  Blocks:false Image:@"Sprout_Enemy_Sprite0.png" Health:1];
        enemy.ai = ai;
    }
    
    // Projectile Ai
    else if( [name isEqual: @"Projectile"] ) {
        AIBlock ai = ^void(GameEngine* engine, Entity* ent){
            if( ent.lifetime % 2 == 0 ) {
                [ent updateImageTo:@"Projectile_Sprite1.png"];
            }
            else {
                [ent updateImageTo:@"Projectile_Sprite0.png"];
            }
            int moveX = 0;
            int moveY = 0;
            switch ( ent.direction ) {
                case 0:
                    moveX = 0;
                    moveY = -1;
                    break;
                case 1:
                    moveX = 1;
                    moveY = 0;
                    break;
                case 2:
                    moveX = 0;
                    moveY = 1;
                    break;
                case 3:
                    moveX = -1;
                    moveY = 0;
                    break;
                default:
                    break;
            }
            int newX = [ent getXPosition] + moveX;
            int newY = [ent getYPosition] + moveY;
            
            if ( newX < 0 || newX >= [engine.gridView getWidth] || newY < 0 || newY >= [engine.gridView getHeight] ) {
                ent.markedForDeath = true;
            }
            else if ( ((Tile*)engine.grid[newX][newY]).object != nil ) {
                if( [((Tile*)engine.grid[newX][newY]).object isKindOfClass:[Player class]] ) {
                    Player *player = (Player *)((Tile*)engine.grid[newX][newY]).object;
                    [player causeDamage:1];
                }
                ent.markedForDeath = true;
            }
            else {
                [engine updatePositionOfEntity:ent ByX:moveX Y:moveY];
            }
            ent.lifetime++;
        };
        
        enemy = [[Enemy alloc] initWithX:x Y:y
                                   Blocks:false Image:@"Projectile_Sprite0.png" Health:1];
        enemy.ai = ai;
    }
    
    // Slimomancer Ai
    else if( [name isEqual: @"Slimomancer"] ) {
        AIBlock ai = ^void(GameEngine* engine, Entity* ent){
            if( ent.lifetime == 2 ) {
                int frontX = [ent getXPosition];
                int frontY = [ent getYPosition] + 1;
                
                ent.lifetime--;
                
                if ( frontX < 0 || frontX >= [engine.gridView getWidth] || frontY < 0 || frontY >= [engine.gridView getHeight] ) {
                    [engine updatePositionOfEntity:ent ByX:0 Y:-1];
                }
                else if ( ((Tile*)engine.grid[frontX][frontY]).object != nil ) {
                    [engine updatePositionOfEntity:ent ByX:0 Y:-1];
                }
                else {
                    ent.lifetime++;
                    [ent updateImageTo:@"Slimomancer_Enemy_Sprite1.png"];
                }
            }
            else if( ent.lifetime == 3 ) {
                [ent updateImageTo:@"Slimomancer_Enemy_Sprite2.png"];
            }
            else if( ent.lifetime == 4 ) {
                [ent updateImageTo:@"Slimomancer_Enemy_Sprite3.png"];
            }
            else if( ent.lifetime == 5 ) {
                int frontX = [ent getXPosition];
                int frontY = [ent getYPosition] + 1;
                
                Entity * slime = [self createEnemyWithName:@"Slime" AtXPos:frontX YPos:frontY];
                [engine.entitiesToAdd addObject:slime];
                
                [ent updateImageTo:@"Slimomancer_Enemy_Sprite0.png"];
                ent.lifetime = 0;
            }
            else {
                int val = rand() % 101;
                if( val < 50 )
                {
                    int moveX = 0;
                    int moveY = 0;
                    val = rand() % 4;
                    switch ( val ) {
                        case 0:
                            moveX = 0;
                            moveY = -1;
                            break;
                        case 1:
                            moveX = 1;
                            moveY = 0;
                            break;
                        case 2:
                            moveX = 0;
                            moveY = 1;
                            break;
                        case 3:
                            moveX = -1;
                            moveY = 0;
                            break;
                        default:
                            break;
                    }
                    
                    [engine updatePositionOfEntity:ent ByX:moveX Y:moveY];
                }
            }
            ent.lifetime++;
        };
        
        enemy = [[Enemy alloc] initWithX:x Y:y
                                  Blocks:false Image:@"Slimomancer_Enemy_Sprite0.png" Health:1];
        enemy.ai = ai;
    }
    
    // Boss Ai ( Boss not fully implemented, some bugs not solved with larger entity movement )
    else if( [name isEqual: @"Boss"] ) {
        AIBlock ai = ^void(GameEngine* engine, Entity* ent){
            if( ent.lifetime % 10 == 9 )
            {
                [engine updatePositionOfEntity:ent ByX:-1 Y:-1];
            }
            ent.lifetime++;
        };
        
        enemy = [[Boss alloc] initWithX:x Y:y
                                  Blocks:false Image:@"Slime_King_Boss_Sprite.png" Health:6];
        CGRect frame = enemy.objectImageView.frame;
        frame.size.width = 128;
        frame.size.height =128;
        enemy.objectImageView.frame = frame;
        enemy.ai = ai;
        // Boss is 4 tiles large vs regular 1 tile
        [enemy.tiles addObject: [[NSArray alloc] initWithObjects: @0, @1, nil]];
        [enemy.tiles addObject: [[NSArray alloc] initWithObjects: @1, @0, nil]];
        [enemy.tiles addObject: [[NSArray alloc] initWithObjects: @1, @1, nil]];
    }
    
    // Return the created entity
    return enemy;
}

@end
