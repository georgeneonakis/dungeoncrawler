//
//  Boss.h
//  Dungeon Crawler
//
//  Created by Dylan Burden on 2018-12-11.
//  Copyright © 2018 George. All rights reserved.
//

#ifndef Boss_h
#define Boss_h

#import <UIKit/UIKit.h>
#import "Enemy.h"

// Just a tag for a boss
@interface Boss : Enemy


@end

#endif /* Boss_h */
