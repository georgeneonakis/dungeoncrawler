//
//  EnemyFactory.h
//  
//
//  Created by Dylan Burden on 2018-12-11.
//

#import <UIKit/UIKit.h>
#import "Enemy.h"
#import "Boss.h"

@class GameEngine;

@interface EnemyFactory : NSObject

-(Enemy *)createEnemyWithName:(NSString *)name AtXPos:(int)x YPos:(int)y;

@end

