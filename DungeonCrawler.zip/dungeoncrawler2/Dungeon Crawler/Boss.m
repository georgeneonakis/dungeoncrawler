//
//  Boss.m
//  Dungeon Crawler
//
//  Created by Dylan Burden on 2018-12-11.
//  Copyright © 2018 George. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Boss.h"

@implementation Boss

@end
